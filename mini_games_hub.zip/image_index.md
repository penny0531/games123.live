# 游戏图片索引

此文件列出了所有游戏及其对应的图片文件。

| 游戏名称 | 图片文件 |
|---------|---------|
| 2048 | game_3_2048.jpg |
| 8 Ball Pool | game_30_8_ball_pool.jpg |
| Agar.io | game_22_agar.io.jpg |
| Asteroids | game_13_asteroids.jpg |
| Basketball Stars | game_32_basketball_stars.jpg |
| Bejeweled | game_33_bejeweled.jpg |
| Bloons TD | game_8_bloons_td.jpg |
| Bloons Tower Defense 5 | game_2_bloons_tower_defense_5.jpg |
| Breakout | game_6_breakout.jpg |
| Car Racing | game_17_car_racing.jpg |
| Cookie Clicker | game_31_cookie_clicker.jpg |
| FIFA | game_9_fifa.jpg |
| Frogger | game_29_frogger.jpg |
| Hole.io | game_36_hole.io.jpg |
| Kingdom Rush | game_34_kingdom_rush.jpg |
| Krunker.io | game_28_krunker_io.jpg |
| Minesweeper | game_27_minesweeper.jpg |
| Mini Golf King | game_14_mini_golf_king.jpg |
| Moto X3M | game_5_moto_x3m.jpg |
| Pac-Man | game_7_pac_man.jpg |
| Paper.io | game_35_paper.io.jpg |
| Plants vs Zombies | game_10_plants_vs_zombies.jpg |
| Rocket League | game_39_rocket_league.jpg |
| Shell Shockers | game_21_shell_shockers.jpg |
| SimCity | game_38_simcity.jpg |
| Slither.io | game_23_slither.io.jpg |
| Snake | game_37_snake.jpg |
| Space Invaders | game_1_space_invaders.jpg |
| Street Fighter II | game_24_street_fighter_ii_browser_vers.jpg |
| Sudoku | game_4_sudoku.jpg |
| Tetris | game_11_tetris.jpg |
| The Sims | game_12_the_sims.jpg |
